import socket
import json

# object is created for the socket
csocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# hostname retrieve
host = socket.gethostname()
csocket.connect((host, 8432))

# define a key-value pair to store data
key_value_pair = {}

# PUT command Implementation
def put(key, value):
    command = f"PUT {key}={value}"
    csocket.sendall(command.encode('ascii'))
    response = csocket.recv(1024)
    key_value_pair[key] = value
    print(f" PUT '{key}={value}'")
    print("Request forwarded to the server")
    print("*****************************")

# GET command Implementation
def get(key):
    command = f"GET {key}"
    csocket.sendall(command.encode())
    response = csocket.recv(1024)
    value = json.loads(response.decode())
    if value is None:
        print(f"'{key}' does not exist")
    else:
        print(f"The value for key '{key}' is '{value}'.")
    print("*********************************")

# DUMP command Implementation
def dump():
    command = "DUMP"
    csocket.sendall(command.encode())
    response = csocket.recv(1024)
    key_value_pair = response.decode()
    if not key_value_pair :
        print("keys are not present.")
    else:
        print("keys on the server are:",key_value_pair)
    print("*****************************")

# define a function to handle the REMOVE command
def remove(key):
    command = f"REMOVE {key}"
    csocket.sendall(command.encode())
    response = csocket.recv(1024)
    if response.decode() == "OK":
        del key_value_pair[key]
        print(f"'{key}'removed from the server.")
    else:
        print(f"'{key}' not exist on the server.")
    print("************************************")

# display options to the user
while True:
    # start a loop to handle user input(Exception handling)
    try:
        # get user input for the selected option
        command = input("Enter 'put', 'get', 'dump', or 'remove', 'exit' to exit: ")
    except ValueError:
        print("Invalid input. Please enter a valid command.")
        continue

    if command == 'put':
        key = input("Enter key: ")
        value = input("Enter value: ")
        put(key, value)
    elif command == 'get':
        key = input("Enter key: ")
        get(key)
    elif command == 'dump':
        dump()
    elif command == 'remove':
        key = input("Enter key to remove: ")
        remove(key)
    elif command == "exit":
        break
    else:
        print("Invalid command. Please try again.")

# close the socket
csocket.close()
