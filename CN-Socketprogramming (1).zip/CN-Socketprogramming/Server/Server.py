import socket
import json
# define a key-value pair to store data
key_value_pair = {}
# object is created for the socket
ssocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# hostname retrieve
host = socket.gethostname()

# bind the socket to a public host, port
ssocket.bind((host, 8432))

ssocket.listen(1)

print("Server...")
csocket, address = ssocket.accept()

# start a loop to listen for incoming connections
while True:
    
    response = csocket.recv(1024).decode()
    if response == "DUMP":
       command =  response
    else:
        command, key_value = response.split(' ')

    # handle the PUT command
    if command == "PUT":
        key, value = key_value.split('=')
        key_value_pair[key] = value
        result = "OK"
    
    # handle the GET command
    elif command == "GET":
        key = key_value
        value = key_value_pair.get(key, None)
        result = json.dumps(value)
    
    # handle the DUMP command
    elif command == "DUMP":
        result = ' '.join(key_value_pair.keys())
    
    # handle the REMOVE command
    elif command == "REMOVE":
        key = key_value
        if key in key_value_pair:
            del key_value_pair[key]
            result = "OK"
        else:
            result = "NOT FOUND"
    
    # send the response to the client
    csocket.sendall(result.encode())
